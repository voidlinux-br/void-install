complete -c xnodev -f
