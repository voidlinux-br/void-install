complete -c xclash -f
