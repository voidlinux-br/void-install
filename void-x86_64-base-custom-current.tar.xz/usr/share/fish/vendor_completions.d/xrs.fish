complete -c xrs -f
