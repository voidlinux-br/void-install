complete -c xbarf -f
