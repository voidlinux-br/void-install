complete -c xmandoc -f
